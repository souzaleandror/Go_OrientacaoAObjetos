package clientes

type Titular struct {
	Nome      string
	CPF       string
	Profissao string
}
