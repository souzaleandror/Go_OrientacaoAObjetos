# Go OO - Aula 4 - "Composição e encapsulamento"
> Código da Alura cursos online

![](/go_alura_logo.png)



