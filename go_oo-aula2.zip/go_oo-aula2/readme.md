# Go OO - Aula 2 - "Referência, ponteiro e método"
> Código da Alura cursos online

![](/go_alura_logo.png)



